# INRI — Navigation Risk Classification

A machine learning and rule-based framework for identifying and assessing navigation failures across India.

## What it does

- Classifies navigation failures into 5 categories
- Compares Random Forest, Gradient Boosting, SVM and KNN
- Calculates an INRI risk score
- Applies domain-based safety rules
- Produces RED, AMBER and GREEN route alerts

## Built With

![Python](https://img.shields.io/badge/Python-31543F?style=for-the-badge&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-3F6B50?style=for-the-badge&logo=pandas&logoColor=white)
![Scikit Learn](https://img.shields.io/badge/Scikit--Learn-527A5D?style=for-the-badge&logo=scikitlearn&logoColor=white)
![Matplotlib](https://img.shields.io/badge/Matplotlib-6B8F71?style=for-the-badge&logo=python&logoColor=white)

## Results

**Best Model:** KNN  
**Accuracy:** 81.8%  
**F1 Score:** 78.8%  
**5-Fold CV:** 65.6% ± 8.8%

## Visual Analysis

### Severity & Incident Categories

<img src="assets/fig1_severity_category.png" width="90%">

### State & Seasonal Distribution

<img src="assets/fig2_state_season.png" width="90%">

### Model Comparison & Confusion Matrix

<img src="assets/fig3_model_comparison.png" width="90%">

### Feature Importance & Terrain Analysis

<img src="assets/fig4_importance_heatmap.png" width="90%">

### Signal & Time-of-Day Analysis

<img src="assets/fig5_signal_time.png" width="90%">

## Notebook

[Open the complete analysis notebook](./INRI-Navigation-Risk-Classification.ipynb)

<div align="center">

Built with Python · ML · Data Analysis

</div>
